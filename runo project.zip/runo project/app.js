const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const port = process.env.PORT || 3000;

mongoose.connect('mongodb://localhost/vaccineApp', { useNewUrlParser: true, useUnifiedTopology: true });

const User = mongoose.model('User', {
  name: String,
  phoneNumber: String,
  password: String,
  age: Number,
  pincode: String,
  aadharNo: String,
  vaccinationStatus: String,
  firstDoseSlot: String,
  secondDoseSlot: String,
});

const Slot = mongoose.model('Slot', {
  date: Date,
  startTime: String,
  endTime: String,
  availableDoses: Number,
  vaccinationStatus: String,
  registeredUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
});

app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.send('Welcome to the API');
});

// User Registration
app.post('/api/register', async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const newUser = new User({
      name: req.body.name,
      phoneNumber: req.body.phoneNumber,
      password: hashedPassword,
      age: req.body.age,
      pincode: req.body.pincode,
      aadharNo: req.body.aadharNo,
      vaccinationStatus: 'none',
    });
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// User Login
app.post('/api/login', async (req, res) => {
  try {
    const user = await User.findOne({ phoneNumber: req.body.phoneNumber });

    if (!user || !(await bcrypt.compare(req.body.password, user.password))) {
      res.status(401).json({ error: 'Invalid credentials' });
      return;
    }

    const token = jwt.sign({ userId: user._id }, 'b831be3e9bffeb0045023bfe0106f3891bc0866d8ab5735e8ca165b557873043', { expiresIn: '1h' });
    res.status(200).json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// View Available Slots
app.get('/api/slots', async (req, res) => {
  try {
    const date = new Date(req.query.date);
    const vaccinationStatus = req.query.vaccinationStatus || 'none';

    const slots = await Slot.find({
      date: date,
      vaccinationStatus: vaccinationStatus,
      availableDoses: { $gt: 0 },
    });

    res.status(200).json(slots);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Register for a Slot
app.post('/api/register-slot', async (req, res) => {
  try {
    // Implement registration logic here
    // - Check slot availability
    // - Update available doses
    // - Add user to registeredUsers array
    // - Update user's vaccination status

    res.status(201).json({ message: 'Slot registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
